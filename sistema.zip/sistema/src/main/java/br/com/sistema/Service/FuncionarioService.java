package br.com.sistema.Service;

import br.com.sistema.model.Funcionario;

import java.util.List;

public interface FuncionarioService {

    public Funcionario findbyid(Long id);
    public List<Funcionario> findAll();

    List<Funcionario> finAll();

    public boolean save (Funcionario funcionario);
    public boolean delete (Long id);


}
